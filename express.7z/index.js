import express from 'express'
import path from 'path'
import { requestTime, logger } from './middlewares.js'

const PORT = process.env.PORT ?? 3000
const app = express()
const __dirname = path.dirname('')

app.set('view engine', 'ejs')
app.set('views', path.resolve(__dirname, 'ejs'))

app.use(express.static(path.resolve(__dirname, 'static')))
app.use(requestTime)
app.use(logger)

app.get('/', (req, res) => {
  res.render('index', { title: 'Main Page' })
})

app.get('/features', (req, res) => {
  res.render('features', { title: 'Features Page' })
})

app.listen(3000, () => {
  console.log(`server has been started on PORT ${PORT}`)
})
